# Design Knowledge Base

A growing research library for learning, reviewing, and building better interfaces.

## Start here

- [Design playbook](library/uiux-design-playbook.md) — nine lessons, examples and exercises.
- [Worked cases](library/design-judgment-worked-cases.md) — resolve competing guidance and test explanations.
- [Research inbox](Research%20Inbox.md) — capture new clips and questions.
- [Sources](Sources.csv) — 41 references with URLs, inspection dates and limitations.
- [Record templates](templates/records.md) — document sources, findings and decisions.

## How to use the library

Learn a principle → inspect the relevant source → apply it to a specific user task → verify the outcome.

Requirements, recommendations, project choices and hypotheses are kept distinct. An inspected source is not proof of a site-specific result.

## Research and evidence

- [Knowledge policy](KNOWLEDGE-POLICY.md)
- [Readable source catalog](SOURCES.md)
- [Research study worksheet](library/mindleverx-research-worksheet.md)
- [Historical MindLeverX case observations](FINDINGS.md)
- [Original collection index](README.md)
- [Import provenance](Import%20Provenance.md)

## Project boundary

MindLeverX's active development handoff is separate and belongs in that coding repository. The examples here are historical teaching material, not a second development backlog.

## Future reuse

[Skills, plugins and other reuse](REUSE.md). Notion is the intended research home. Any later GitHub release will be a deliberate selected export, not an automatically synchronized copy.

Prepared 19 September 2026. Sources retain their original check dates. The collection includes expert review and limited browser checks; no full accessibility audit or representative-user study has been completed.

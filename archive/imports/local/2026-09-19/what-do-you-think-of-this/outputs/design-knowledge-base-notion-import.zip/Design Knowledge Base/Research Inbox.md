# Research Inbox

Capture new sources, examples, screenshots and questions here. A saved clip is a lead to inspect, not automatically verified guidance.

## Suggested source fields

Name · URL · Topic · Status · Date checked · What it supports · Limits · Notes

## Research flow

Inbox → Read → Verify → Synthesize → Apply

Add new clips to the Sources database, then mark their review status after reading. Keep screenshot context, original URL and capture date. The existing Sources rows are a catalog of references already inspected; they are not full saved copies of those websites.

## Questions to pursue next

- Which navigation labels help the intended audience predict the destination?
- Which measurement definitions produce consistent interpretations?
- How should essential disclosure remain visible while methodology stays accessible?
- What evidence would change a current recommendation?

See the research worksheet for proposed study tasks. No participant study has been conducted.

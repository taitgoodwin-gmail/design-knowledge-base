# Import provenance

Original collection imported on 19 September 2026. These hashes describe the original saved edition, before Notion link adaptation. Original local files remain preserved.

| Document | Original SHA-256 |
|---|---|
| library/design-judgment-worked-cases.md | d3ebd054093f2aabebe580c930da3bb6be275414b86563093fe609e5360962b4 |
| library/mindleverx-research-worksheet.md | 89d55d6a02b2fac2b541431872278c5e8229b29798ad00941448067112a2b560 |
| library/uiux-design-playbook.md | d0475acd99b83e100cdf73b32dbc8dbe0b2dfd91bccd967ea67628316ce4be65 |
| evidence/advanced-uiux-teaching-evidence.md | cd42b1dc857cbe7507eff6e191e584e57976772c775e27670a97b70693552c49 |
| evidence/design-benchmark-evidence.md | f0826400036c87a0007dd7565c07c4da4b96a6a079ddf50e6afec8cf53f13fcc |
| evidence/playbook-verification.md | 9144f51ab2f6ca60235ddf058f04c45e48497d0a3762fda4571cf12352a6d5f8 |
| evidence/research-teaching-completion-audit.md | 29b56b6a1ab09cd71338937fc8f049831e4139c4fedf28560df198ad0c0be06b |
| evidence/uiux-harmonization-evidence.md | 81fa175cfc0c4341a74fbc3359531b53bb27ebae381a353143eeeef23d530a67 |
| governance/official-source-build-practice.snapshot.md | f6562da31c192db7b929eb21765ff037e3bb3f55c695af6ebfd44cc3542f8ded |
